#include "libndktest.h"

int main(int argc, char *argv[]) {
    libndk_init();
    libndk_test();
    libndk_free();

    return 0;
}

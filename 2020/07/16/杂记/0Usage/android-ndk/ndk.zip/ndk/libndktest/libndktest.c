#define TAG "NDK"

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <android/log.h>

#define ALOGD(fmt, ...) __android_log_print(ANDROID_LOG_DEBUG, TAG, fmt, ## __VA_ARGS__)

void libndk_init() {
    ALOGD("%s(L%d): init successful", __FUNCTION__, __LINE__);
}

void libndk_test() {
    ALOGD("%s(L%d): hello test", __FUNCTION__, __LINE__);
}

void libndk_free() {
    ALOGD("%s(L%d): free successful", __FUNCTION__, __LINE__);
}

#ifndef LIBNDKTEST_H
#define LIBNDKTEST_H

void libndk_init();

void libndk_test();

void libndk_free();

#endif /* end of include guard: LIBNDKTEST_H */
